import { createRouter, createWebHistory } from 'vue-router'
import { useTokenStore } from '@/stores'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
		{
			path: '/',
			name: 'login',
			component: () => import('@/views'),
		},
		{
			path: '/userHome',
			name: 'userHome',
			component: () => import('@/views/userHome'),
			children: [
				{
					path: '/look',
					name: 'Look',
					component: () => import('@/views/user/supv/look')
				},
				{
					path: '/info',
					name: 'Info',
					component: () => import('@/views/user/sys/info')
				},
				{
					path: '/order_list',
					name: 'listlistOrder',
					component: () => import('@/views/user/sys/order_list')
				},
				{
					path: '/success',
					name: 'paySuccess',
					component: () => import('@/views/user/pay/success')
				},
			],

		},
		{
			path: '/adminHome',
			name: 'adminHome',
			component: () => import('@/views/adminHome'),
			children: [
				{
					path: '/userlook',
					name: 'usersupvLook',
					component: () => import('@/views/user/supv/look')
				},
				{
					path: '/userinfo',
					name: 'usersysInfo',
					component: () => import('@/views/user/sys/info')
				},
				{
					path: '/userorder_list',
					name: 'userlistOrder',
					component: () => import('@/views/user/sys/order_list')
				},
				{
					path: '/usersuccess',
					name: 'userpaySuccess',
					component: () => import('@/views/user/pay/success')
				},
			],
		
		}
	]
})
router.beforeEach((to, from, next) => {
	const tokenStore = useTokenStore()
	const token = tokenStore.getToken()
	if (token || to.fullPath === '/') {
		next()
	} 
	else {
		next('/')
	}
})
export default router
