<template>
  <!-- 登录整体容器，增加样式使居中显示 -->
  <div class="login-container"> 
    <!-- 页面标题，改为“医生登录系统” -->
    <h1>颐养天年养老院</h1> 
    <p class="sub-title">岁月温情处，夕阳暖心家</p >
    <!-- 身份选择区域 -->
    <div class="identity-select">
      <el-radio-group v-model="selectedIdentity" size="medium">
        <el-radio label="user">用户登录</el-radio>
        <el-radio label="admin">管理员登录</el-radio>
      </el-radio-group>
    </div>
    <el-form
      ref="formObj"
      :rules="rules"
      :model="zxyform"
      label-width="80px"
    >
      <!-- 登录名输入项 -->
      <el-form-item label="登录名" prop="username"> 
        <el-input
          v-model="zxyform.username"
          placeholder="请输入手机号/电子邮件"
        ></el-input>
      </el-form-item>
      <!-- 登录密码输入项，增加显示密码切换 -->
      <el-form-item label="登录密码" prop="password"> 
        <el-input
          v-model="zxyform.password"
          placeholder="请输入登录密码"
          show-password
        ></el-input>
      </el-form-item>
      <!-- 记住登录状态与忘记密码 -->
      <el-form-item label-width="0px"> 
        <div style="display: flex; align-items: center;">
          <el-link type="primary" @click="findpwd" style="margin-left: auto;">忘记密码？</el-link>
        </div>
      </el-form-item>
      <!-- 登录按钮 -->
      <el-form-item label-width="0px"> 
        <el-button
          style="width: 100%;"
          type="primary"
          @click="handleLogin"
        >
          登录
        </el-button>
      </el-form-item>
    </el-form>
<!--    注册相关，若不需要可调整或删除，这里保留示例
    <div class="extra-op"> 
      <el-link type="primary" @click="regist">注册</el-link>
    </div>
    <!-- 注册相关：仅当身份为user时显示（核心修改） --> 
<!--    <div class="extra-op" v-if="selectedIdentity === 'user'"> 
      <el-link type="primary" @click="regist">注册</el-link>
    </div> -->
    <!-- 版权信息 -->
    <p class="copyright">© 2025 医疗服务平台 版权所有</p > 
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
// 假设你的 Editor 组件路径正确，若不需要注册弹窗可调整
import Editor from '@/views/user/regist' 
import { post } from '@/axios'
import { useTokenStore } from '@/stores'
import router from '@/router'

const tokenStore = useTokenStore()
const formObj = ref()
const emits = defineEmits(['update:r'])
// 新增：身份选择变量
const selectedIdentity = ref('user')

// 表单数据
const zxyform = reactive({ 
  username: '',
  password: ''
})
// 记住登录状态
const remember = ref(false) 
// 表单校验规则
const rules = { 
  username: [
    {
      required: true,
      message: '请输入登录名',
      trigger: 'blur'
    }
  ],
  password: [
    {
      required: true,
      message: '请输入登录密码',
      trigger: 'blur'
    }
  ]
}

// 忘记密码方法
const findpwd = () => { 
  emits('update:r', 180)
}
// 注册弹窗控制，若不需要可简化
const showDialog = ref(false) 
const regist = () => {
  showDialog.value = true
}

// 登录方法
const login = () => { 
  post('/user/login', zxyform, (content) => {
    tokenStore.setToken(content)
    router.push('/userHome')
  }, formObj)
}
const adminLogin = () => { 
  post('/admin/login', zxyform, (content) => {
    tokenStore.setToken(content)
    router.push('/adminHome')
  }, formObj)
}
// 统一登录处理方法
const handleLogin = () => {
  // 先校验表单合法性
  formObj.value.validate((isValid) => {
    if (isValid) {
      // 根据选中的身份调用不同登录方法
      if (selectedIdentity.value === 'user') {
        login()
      } else {
        adminLogin()  // 此处需与方法名一致（修复原大小写问题）
      }
    }
  })
}
</script>

<style scoped lang="scss">
/* 登录容器样式，使内容居中 */
.login-container { 
  text-align: center;
  margin: 50px auto;
  width: 400px;
  padding: 30px;
  background: rgba(255, 255, 255, 1.0);
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
// 页面标题样式
h1 { 
  margin-bottom: 10px;
  font-size: 20px;
  font-weight: bold;
}
// 副标题样式
.sub-title { 
  margin-bottom: 20px;
  color: #999;
}
// 身份选择区域样式（新增，优化排版）
.identity-select {
  margin-bottom: 25px;
  text-align: left;
  padding-left: 2px;
}
// 表单样式
.el-form { 
  margin-top: 25px;
}
// 额外操作（注册等）样式
.extra-op { 
  margin-top: 15px;
}
// 版权信息样式
.copyright { 
  margin-top: 20px;
  color: #999;
  font-size: 12px;
}
</style>