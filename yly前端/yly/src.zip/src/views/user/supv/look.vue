<template>
	这里是查看老人起居的地方
</template>

<script>
</script>

<style>
</style>