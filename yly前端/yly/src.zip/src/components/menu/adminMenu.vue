<template>
  <el-menu
		router
		style="font-size: 20px;"
		active-text-color="#f330f9"
			        background-color="#49e1ff"
					text-color="#170fff">
		<el-sub-menu index="sys">
			<template #title>管理员菜单</template>
			<el-menu-item index="/userinfo">预约入住</el-menu-item>
			<el-menu-item index="/userorder_list">所有老人</el-menu-item>
		</el-sub-menu>
		<el-sub-menu index="pms">
			<template #title>业务管理</template>
			<el-menu-item-group>
				<template #title>生活娱乐</template>
				<el-menu-item index="/userlook">查看起居</el-menu-item>
				<el-menu-item index="/regist/list">活动安排</el-menu-item>
			</el-menu-item-group>
				<el-menu-item-group>
					<template #title>医疗康复</template>
					<el-menu-item index="/doctor/list">康复训练</el-menu-item>
					<el-menu-item index="/doctor/list">饮食安排</el-menu-item>
				</el-menu-item-group>
				<el-menu-item-group>
					<template #title>体检信息</template>
					<el-menu-item index="/doctor/list">查看体检信息</el-menu-item>
					<el-menu-item index="/doctor/list">上传体检信息</el-menu-item>
				</el-menu-item-group>
		</el-sub-menu>
	</el-menu>
</template>

<script setup>

</script>

<style scoped lang="scss">
.el-menu {
	height: 100%;
}
</style>