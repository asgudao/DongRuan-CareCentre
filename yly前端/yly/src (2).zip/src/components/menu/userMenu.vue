<template>
  <el-menu
		router
		style="font-size: 20px;"
		active-text-color="#00ffff"
			        background-color="#00aaff"
					text-color="#55ffff">
		<el-sub-menu index="sys">
			<template #title>老人报名</template>
			<el-menu-item index="/info">预约入住</el-menu-item>
			<el-menu-item index="/order_list">我的预约</el-menu-item>
		</el-sub-menu>
		<el-sub-menu index="supv">
			<template #title>老人监管</template>
				<el-menu-item index="/look_training">查看训练</el-menu-item>
				<el-menu-item index="/look_check">查看体检</el-menu-item>
		</el-sub-menu>
	</el-menu>
</template>

<script setup>

</script>

<style scoped lang="scss">
.el-menu {
	height: 100%;
}
</style>