import { createRouter, createWebHistory } from 'vue-router'
import { useTokenStore } from '@/stores'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
		{
			path: '/',
			name: 'login',
			component: () => import('@/views'),
		},
		{
			path: '/userHome',
			name: 'userHome',
			component: () => import('@/views/userHome'),
			children: [
				{
					path: '/look_training',
					name: 'LookTraining',
					component: () => import('@/views/user/supv/look_training')
				},
				{
					path: '/look_check',
					name: 'LookChaeck',
					component: () => import('@/views/user/supv/look_check')
				},
				{
					path: '/info',
					name: 'Info',
					component: () => import('@/views/user/sys/info')
				},
				{
					path: '/order_list',
					name: 'listlistOrder',
					component: () => import('@/views/user/sys/order_list')
				},
				{
					path: '/success',
					name: 'paySuccess',
					component: () => import('@/views/user/pay/success')
				},
			],

		},
		{
			path: '/adminHome',
			name: 'adminHome',
			component: () => import('@/views/adminHome'),
			children: [
				{
					path: '/userinfo',
					name: 'usersysInfo',
					component: () => import('@/views/user/sys/info')
				},
				{
					path: '/userorder_list',
					name: 'userlistOrder',
					component: () => import('@/views/user/sys/order_list')
				},
				{
					path: '/usersuccess',
					name: 'userpaySuccess',
					component: () => import('@/views/user/pay/success')
				},
				{
					path: '/add_training',
					name: 'add_training',
					component: () => import('@/views/admin/training/add_training')
				},
				{
					path: '/training_list',
					name: 'training_list',
					component: () => import('@/views/admin/training/training_list')
				},
				{
					path: '/check_update',
					name: 'check_update',
					component: () => import('@/views/admin/elder_check/check_update')
				},
				{
					path: '/check_list',
					name: 'check_list',
					component: () => import('@/views/admin/elder_check/check_list')
				},
				
			],
		
		}
	]
})
router.beforeEach((to, from, next) => {
	const tokenStore = useTokenStore()
	const token = tokenStore.getToken()
	if (token || to.fullPath === '/') {
		next()
	} 
	else {
		next('/')
	}
})
export default router
