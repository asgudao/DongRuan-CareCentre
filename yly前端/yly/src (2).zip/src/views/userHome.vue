<template>
  <el-container class="wrapper">
		<el-aside width="200px">
			<LRmenu></LRmenu>
		</el-aside>
		<el-container>
			<el-header>
				<h1>东软养老院</h1>
			</el-header>
			<el-main>
				<router-view />
			</el-main>
			<el-footer>
				<h3>感谢您对东软养老院的支持</h3>
			</el-footer>
		</el-container>
	</el-container>
</template>

<script setup>
import LRmenu from '@@/menu/userMenu'
</script>

<style scoped lang="scss">
.wrapper {
	height: 100vh;
	.el-header, .el-footer {
		background-color: #0463fa;
		color: #ffffff;
		display: flex;
		align-items: center;
		letter-spacing: 0.5rem;
	}
}
</style>