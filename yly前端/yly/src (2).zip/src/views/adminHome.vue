<template>
	<div class="background-container">
	   <!-- 原有内容包裹在新容器中 -->
  <el-container class="wrapper">
		<el-aside width="200px">
			<PcMenu />
		</el-aside>
		<el-container>
			<el-header style="height: 110px;">
				<h1 style="font-size: 1.875rem;">欢迎来到东软颐养中心管理员界面</h1>
			</el-header>
			<el-main>
				<router-view />
			</el-main>
			<el-footer >
				<h3>2023东软颐养中心版权所有</h3>
			</el-footer>
		</el-container>
	</el-container>
	   </div>
</template>

<script setup>
import PcMenu from '@@/menu/adminMenu'
</script>

<style scoped lang="scss">
.wrapper {
	height: 100vh;
	.el-header, .el-footer {
		height: 70px;
		background-color: #53ffc0;
		color: #000000;
		display: flex;
		align-items: center;
		letter-spacing: 0.5rem;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.background-container {
  height: 100vh;
  width: 100vw;
  background-image: url('/public/pic1.png'); /* 图片路径 */
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>