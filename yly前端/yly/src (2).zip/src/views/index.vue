<template>
	<div class="wrapper" >
		<div class="content" :style="{ transform: 'rotateY(' + r + 'deg)' }">
			<Login class="login" v-model:r="r" />
		</div>
	</div>
</template>

<script setup>
import Login from '@/views/login'
import { ref } from 'vue'
const r = ref(0)
</script>

<style scoped lang="scss">
.wrapper {
	height: 100vh;
	width: 100vw;
	display: flex;
	align-items: center;
	justify-content: center;
	perspective: 1000px;
	background-image: url("login.png");
	background-size: cover;
	background-position: center;
}</style>