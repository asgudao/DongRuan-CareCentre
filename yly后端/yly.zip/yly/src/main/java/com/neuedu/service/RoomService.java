package com.neuedu.service;

import com.neuedu.entity.Nurse;
import com.neuedu.entity.Room;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 养老院房间信息表 服务类
 * </p>
 *
 * @author hyx
 * @since 2025-08-22
 */
public interface RoomService extends IService<Room> {
    List<Room> list();
}
