package com.neuedu.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.entity.SysFile;
import com.neuedu.service.SysFileService;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.errors.*;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * <p>
 * 文件表 服务实现类
 * </p>
 *
 * @author hyx
 * @since 2025-08-07
 */
@Service
public class SysFileServiceImpl implements SysFileService {

    @Value("${minio.endpoint}")
    String endpoint;
    @Value("${minio.accesskey}")
    String accesskey;
    @Value("${minio.secretkey}")
    String secretkey;

    @Override
    public String upload(MultipartFile file, String bucket) throws IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        MinioClient client =MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accesskey,secretkey)
                .build();
        String filename=getFileName(file.getOriginalFilename());
        PutObjectArgs args = PutObjectArgs.builder()
                .bucket(bucket)
                .contentType(file.getContentType())
                .object(filename)
                .stream(file.getInputStream(),file.getSize(),-1)
                .build();
        String path=String.format("/%s/%s",bucket,filename);
        client.putObject(args);
        return path;
    }
    private String getFileName (String oldName){
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
        String extension = FilenameUtils.getExtension(oldName);
        return time+"."+extension;
    }

    @Override
    public boolean saveBatch(Collection<SysFile> entityList, int batchSize) {
        return false;
    }

    @Override
    public boolean saveOrUpdateBatch(Collection<SysFile> entityList, int batchSize) {
        return false;
    }

    @Override
    public boolean updateBatchById(Collection<SysFile> entityList, int batchSize) {
        return false;
    }

    @Override
    public boolean saveOrUpdate(SysFile entity) {
        return false;
    }

    @Override
    public SysFile getOne(Wrapper<SysFile> queryWrapper, boolean throwEx) {
        return null;
    }

    @Override
    public Optional<SysFile> getOneOpt(Wrapper<SysFile> queryWrapper, boolean throwEx) {
        return Optional.empty();
    }

    @Override
    public Map<String, Object> getMap(Wrapper<SysFile> queryWrapper) {
        return null;
    }

    @Override
    public <V> V getObj(Wrapper<SysFile> queryWrapper, Function<? super Object, V> mapper) {
        return null;
    }

    @Override
    public BaseMapper<SysFile> getBaseMapper() {
        return null;
    }

    @Override
    public Class<SysFile> getEntityClass() {
        return null;
    }
}
