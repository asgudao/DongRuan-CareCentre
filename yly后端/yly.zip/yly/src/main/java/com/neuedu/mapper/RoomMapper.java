package com.neuedu.mapper;

import com.neuedu.entity.Room;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 养老院房间信息表 Mapper 接口
 * </p>
 *
 * @author hyx
 * @since 2025-08-22
 */
public interface RoomMapper extends BaseMapper<Room> {

}
