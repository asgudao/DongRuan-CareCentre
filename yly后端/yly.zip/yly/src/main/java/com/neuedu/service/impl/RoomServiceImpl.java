package com.neuedu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.entity.Nurse;
import com.neuedu.entity.Room;
import com.neuedu.mapper.RoomMapper;
import com.neuedu.service.RoomService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 养老院房间信息表 服务实现类
 * </p>
 *
 * @author hyx
 * @since 2025-08-22
 */
@Service
public class RoomServiceImpl extends ServiceImpl<RoomMapper, Room> implements RoomService {

    @Override
    public List<Room> list() {
        QueryWrapper<Room> wrapper = new QueryWrapper<>();
        wrapper.eq("status", 0);
        return this.list(wrapper);
    }
}
