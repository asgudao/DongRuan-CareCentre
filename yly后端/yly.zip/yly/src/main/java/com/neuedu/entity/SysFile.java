package com.neuedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * <p>
 * 文件表
 * </p>
 *
 * @author 王禹
 * @since 2025-08-07
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("sys_file")
public class SysFile implements Serializable {

    private static final long serialVersionUID = 1L;

    public SysFile(String md5, String contentType, Long size, String path) {
        this.md5 = md5;
        this.contentType = contentType;
        this.size = size;
        this.path = path;
    }

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 文件md5
     */
    private String md5;

    /**
     * 文件类型
     */
    private String contentType;

    /**
     * 文件大小
     */
    private Long size;

    /**
     * 文件路径
     */
    private String path;
}
