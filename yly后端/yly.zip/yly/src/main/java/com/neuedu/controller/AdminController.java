package com.neuedu.controller;

import com.neuedu.entity.Elder;
import com.neuedu.service.AdminService;
import com.neuedu.service.ElderService;
import com.neuedu.vo.ResultJson;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 管理员信息表 前端控制器
 * </p>
 *
 * @author yy
 * @since 2025-08-25
 */
@RestController
@RequestMapping("/admin")
public class AdminController {
    @Resource
    AdminService adminService;
    @Resource
    ElderService elderService;
    @PostMapping("/login")
    ResultJson<String> login(String username, String password) {
        return ResultJson.success(adminService.login(username, password));
    }
    @GetMapping("/list")
    ResultJson<List<Elder>> getAllElders(Long open_id, String checkInTime, Integer active) {
        List<Elder> elders = elderService.listAll(open_id, checkInTime, active);
        return ResultJson.success(elders);
    }
}
