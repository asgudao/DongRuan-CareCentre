package com.neuedu.controller;

import com.neuedu.service.AdminService;
import com.neuedu.vo.ResultJson;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 管理员信息表 前端控制器
 * </p>
 *
 * @author yy
 * @since 2025-08-25
 */
@RestController
@RequestMapping("/admin")
public class AdminController {
    @Resource
    AdminService adminService;
    @PostMapping("/login")
    ResultJson<String> login(String username, String password) {
        return ResultJson.success(adminService.login(username, password));
    }
}
