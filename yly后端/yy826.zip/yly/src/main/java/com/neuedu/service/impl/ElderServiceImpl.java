package com.neuedu.service.impl;

import com.alipay.api.AlipayApiException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.neuedu.config.NeueduException;
import com.neuedu.entity.Elder;
import com.neuedu.mapper.ElderMapper;
import com.neuedu.service.ElderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.service.PayService;
import com.neuedu.util.PayContent;
import com.neuedu.vo.ResultJson;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;

/**
 * <p>
 * 养老院老人信息表 服务实现类
 * </p>
 *
 * @author hyx
 * @since 2025-08-22
 */
@Service

public class ElderServiceImpl extends ServiceImpl<ElderMapper, Elder> implements ElderService {
    @Resource
    PayService payService;
    @Override
    public String add(Elder elder, Long openId) throws AlipayApiException, JsonProcessingException {
        elder.setuserId(openId);
        Random random =new Random(openId);
        String outTradeNo=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"))+ String.valueOf(random.nextInt(1000000,9999999));
        elder.setoutTradeNo(outTradeNo);
        if(this.save(elder)) {
            PayContent payContent = new PayContent(
                    outTradeNo,
                    String.valueOf(String.valueOf(elder.getPrice())),
                    "入住费",
                    "入住费",
                    "FAST_INSTANT_TRADE_PAY"
            );
            return payService.pay(payContent);
        }
        throw new NeueduException("缴费失败");
    }

    @PostMapping("/pay")
    ResultJson<String> pay(PayContent payContent) throws AlipayApiException, JsonProcessingException {
        payContent.setSubject("ruzhu费");
        payContent.setProduct_code("FAST_INSTANT_TRADE_PAY");
        return ResultJson.success(payService.pay(payContent));
    }

    @Override
    public List<Elder> list(Long open_id, String checkInTime, Integer active) {
        QueryWrapper<Elder> wrapper=new QueryWrapper<>();
        wrapper.eq("user_id",open_id);
        if(null!=active){
            wrapper.eq("active",active);
        }
        return this.list(wrapper);
    }

    @Override
    public Boolean update(HttpServletRequest request) throws AlipayApiException {
        if(payService.check(request)){
            String outTradeNo=request.getParameter("out_trade_no");
            Elder elder=new Elder();
            elder.setActive(1);
            UpdateWrapper<Elder> wrapper=new UpdateWrapper<>();
            wrapper.eq("out_trade_no",outTradeNo);
            return this.update(elder,wrapper);
        }else{
            throw new NeueduException("支付失败");
        }
    }
}
